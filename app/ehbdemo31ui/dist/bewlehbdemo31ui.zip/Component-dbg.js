sap.ui.define(['sap/fe/core/AppComponent'], function(AppComponent) {
    'use strict';

    return AppComponent.extend("be.wl.ehbdemo31ui.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
